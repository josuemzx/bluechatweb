"use client";

import Link from 'next/link';
import { useState } from 'react';
import { usePathname } from 'next/navigation';
import clsx from 'clsx';
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';

const navigation = [
    { name: 'Producto', href: '/product' },
    { name: 'Precios', href: '/pricing' },
    { name: 'Blog', href: '/blog' },
    { name: 'Compañía', href: '/company' },
];

export default function Navbar() {
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const pathname = usePathname();

    // Ocultar Navbar en el Studio
    if (pathname?.startsWith('/studio')) return null;

    return (
        <header className="fixed inset-x-0 top-0 z-50 bg-white/90 backdrop-blur-sm">
            <nav className="flex items-center justify-between px-6 py-2 lg:px-8 max-w-[1440px] mx-auto" aria-label="Global">
                <div className="flex items-center gap-8">
                    <Link href="/" className="-m-1.5 p-1.5 flex items-center gap-2">
                        <span className="sr-only">Bluechat</span>
                        <img
                            className="h-7 w-auto"
                            src="/logo.png"
                            alt="Bluechat"
                        />
                    </Link>
                    <div className="hidden lg:flex lg:gap-x-6">
                        {navigation.map((item) => (
                            <Link
                                key={item.name}
                                href={item.href}
                                className="text-[14px] font-medium leading-6 text-[#5f6368] hover:text-[#202124] transition-colors"
                            >
                                {item.name}
                            </Link>
                        ))}
                    </div>
                </div>

                <div className="flex lg:hidden">
                    <button
                        type="button"
                        className="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-gray-700"
                        onClick={() => setMobileMenuOpen(true)}
                    >
                        <span className="sr-only">Open main menu</span>
                        <Bars3Icon className="h-6 w-6" aria-hidden="true" />
                    </button>
                </div>

                <div className="hidden lg:flex lg:flex-1 lg:justify-end gap-4 items-center">
                    <Link
                        href="https://app.bluechat.lat"
                        className="text-[14px] font-medium text-[#5f6368] hover:text-[#202124] transition-colors"
                    >
                        Iniciar sesión
                    </Link>
                    <Link
                        href="https://bluechat.lat/crear-cuenta/"
                        className="rounded-full bg-[#202124] px-5 py-2 text-[14px] font-medium text-white shadow-sm hover:bg-gray-800 transition-all flex items-center gap-2"
                    >
                        Crear cuenta
                    </Link>
                </div>
            </nav>
        </header>
    );
}
